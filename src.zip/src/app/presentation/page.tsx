"use client";

import Image from "next/image";
import { motion } from "framer-motion";

export default function PresentationPage() {
  return (
    <div className="flex flex-col items-center">
      
      {/* Title Slide */}
      <section className="min-h-screen w-full flex flex-col justify-center items-center px-12 text-center snap-center">
        <motion.span 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1.5, ease: [0.22, 1, 0.36, 1] }}
          className="text-[#BFA37E] text-xs uppercase tracking-[0.4em] font-semibold mb-12 block"
        >
          Confidential Portfolio Review
        </motion.span>
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="font-serif text-6xl md:text-8xl lg:text-[7rem] max-w-6xl leading-[1.1] mb-12"
        >
          Restoration is maintenance.<br/>
          Reanimation is <span className="italic text-[#C8C2B6]">devotion.</span>
        </motion.h1>
      </section>

      {/* Philosophy Slide */}
      <section className="min-h-screen w-full flex items-center px-12 md:px-32 snap-center">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-32 items-center w-full max-w-[1400px] mx-auto">
          <div>
            <span className="text-[#BFA37E] text-[10px] uppercase tracking-[0.3em] font-semibold mb-8 block">The Philosophy</span>
            <h2 className="font-serif text-5xl md:text-7xl leading-[1.1] mb-12">
              We do not build cars.<br/>
              We rebuild <span className="italic text-[#C8C2B6]">memories.</span>
            </h2>
            <div className="w-24 h-[1px] bg-[#BFA37E]/50 mb-12"></div>
            <p className="text-[#C8C2B6] text-xl md:text-2xl leading-[1.8] font-light">
              In an industry obsessed with speed and superficial perfection, we operate with museum-like silence and mechanical obsession. Every nut, bolt, and panel is an opportunity to honor the original creator's intent.
            </p>
          </div>
          <div className="relative h-[70vh] w-full">
            <Image 
              src="/images/macro.jpg" 
              alt="Workshop Detail" 
              fill 
              className="object-cover grayscale"
            />
          </div>
        </div>
      </section>

      {/* Commission Slide */}
      <section className="min-h-screen w-full flex flex-col justify-center px-12 md:px-32 snap-center bg-[#121212] border-y border-[#1F1F1F]">
        <div className="max-w-[1400px] mx-auto w-full">
          <div className="mb-20">
            <span className="text-[#BFA37E] text-[10px] uppercase tracking-[0.3em] font-semibold mb-8 block">Case Study</span>
            <h2 className="font-serif text-6xl md:text-8xl">Commission 014</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-12 gap-16">
            <div className="md:col-span-8 relative h-[60vh]">
              <Image 
                src="/images/hero.jpg" 
                alt="Commission 014" 
                fill 
                className="object-cover grayscale opacity-90"
              />
            </div>
            <div className="md:col-span-4 flex flex-col justify-end">
              <div className="space-y-16">
                <div>
                  <p className="text-[#C8C2B6] text-xs uppercase tracking-[0.3em] mb-3">Vehicle</p>
                  <p className="font-serif text-3xl">1973 Porsche 911 Carrera RS</p>
                </div>
                <div>
                  <p className="text-[#C8C2B6] text-xs uppercase tracking-[0.3em] mb-3">Labor</p>
                  <p className="font-serif text-3xl">3,420 Hours</p>
                </div>
                <div>
                  <p className="text-[#C8C2B6] text-xs uppercase tracking-[0.3em] mb-3">Valuation</p>
                  <p className="font-serif text-3xl text-[#BFA37E]">Investment Grade</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* End Slide */}
      <section className="min-h-screen w-full flex flex-col justify-center items-center px-12 text-center snap-center">
        <h2 className="font-serif text-6xl md:text-8xl mb-12">
          Enter the Atelier.
        </h2>
        <div className="w-24 h-[1px] bg-[#BFA37E] mb-12"></div>
        <p className="text-[#C8C2B6] text-xl uppercase tracking-[0.4em]">
          Annual Capacity: 18 • Remaining: 03
        </p>
      </section>
      
    </div>
  );
}
