"use client";

import { motion } from "framer-motion";

export default function CapacityIndicator() {
  return (
    <div className="w-full bg-[#0B0B0B] border-y border-[#BFA37E]/30 relative overflow-hidden">
      {/* Subtle Grain Overlay */}
      <div 
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.04]"
        style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=%220 0 200 200%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cfilter id=%22noiseFilter%22%3E%3CfeTurbulence type=%22fractalNoise%22 baseFrequency=%220.65%22 numOctaves=%223%22 stitchTiles=%22stitch%22/%3E%3C/filter%3E%3Crect width=%22100%25%22 height=%22100%25%22 filter=%22url(%23noiseFilter)%22/%3E%3C/svg%3E")', backgroundRepeat: 'repeat' }}
      ></div>

      <div className="container mx-auto px-6 md:px-12 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-stone-800/50 py-8 md:py-12">
          {/* Metric 1 */}
          <div className="flex flex-col justify-center items-center px-4">
            <span className="font-mono text-4xl md:text-5xl text-[#F5F2EB] mb-3 tracking-tighter">18</span>
            <span className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-[#C8C2B6]">Annual Capacity</span>
          </div>
          
          {/* Metric 2 */}
          <div className="flex flex-col justify-center items-center px-4">
            <span className="font-mono text-4xl md:text-5xl text-[#BFA37E] mb-3 tracking-tighter">15</span>
            <span className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-[#C8C2B6]">Active Commissions</span>
          </div>
          
          {/* Metric 3 */}
          <div className="flex flex-col justify-center items-center px-4">
            <span className="font-mono text-4xl md:text-5xl text-[#F5F2EB] mb-3 tracking-tighter">03</span>
            <span className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-[#C8C2B6]">Remaining</span>
          </div>
          
          {/* Metric 4 */}
          <div className="flex flex-col justify-center items-center px-4">
            <span className="font-serif text-3xl md:text-4xl text-[#F5F2EB] mb-3 mt-1">2027</span>
            <span className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] text-[#C8C2B6]">Next Opening</span>
          </div>
        </div>
      </div>
      
      {/* Animated progress bar integrated into the bottom border */}
      <motion.div 
        className="absolute bottom-0 left-0 h-[1px] bg-[#BFA37E]"
        initial={{ width: 0 }}
        whileInView={{ width: "83.3%" }} /* 15 out of 18 */
        viewport={{ once: true }}
        transition={{ duration: 2, ease: [0.22, 1, 0.36, 1], delay: 0.5 }}
      />
    </div>
  );
}
